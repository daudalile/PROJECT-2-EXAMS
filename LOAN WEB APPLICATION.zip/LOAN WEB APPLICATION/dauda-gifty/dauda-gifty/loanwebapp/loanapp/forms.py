from django.forms import ModelForm
from .models import applications

class applicationForm(ModelForm):
    class Meta:
        model = applications
        fields = '__all__'